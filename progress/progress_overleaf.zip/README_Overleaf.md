# Overleaf source package

Import this ZIP as a new Overleaf project. Select progress_report.tex as the main document and use pdfLaTeX. The project uses the standard IEEEtran bibliography style. All required generated tables and PDF figures are included. Re-running the experiments is not required to compile.

The original local progress folder also contains raw data, Python scripts, predictions, and a Turkish README; those larger files are intentionally excluded from this source package.
